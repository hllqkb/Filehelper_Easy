---
date: '2024-08-27T18:41:25.801008+08:00'
title: 说说
updated: '2024-08-27T18:41:26.497+08:00'
---
<div id="qexot"></div>
<script src="https://cdn.jsdelivr.net/npm/qexo-static@1.6.0/hexo/talks.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/qexo-static@1.6.0/hexo/talks.css">
<script>showQexoTalks("qexot", "https://www.hllqk.cn/", 5)</script>
