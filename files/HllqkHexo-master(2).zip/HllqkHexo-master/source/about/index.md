---
date: 2022-08-10 15:58:36
title: 关于
updated: 2022-08-10 16:08:50
---`<img align='right' src='https://cloud.shuia.tk/img/d5fb4437-3438-4bbe-af0e-62ba3e57ea37.png'>

# 这里是*hllqk*<img style='border-radius: 50%; height: 30px; width: 30px;' src='https://cdn.shuia.tk/assets/img/logo-circul.png'>

<img align='middle' src="https://visitor-badge.glitch.me/badge?page_id=hllqk" /><img align='middle' src='https://hb.shuia.tk/?text=%E6%98%AF%E5%AD%A6%E7%94%9F%EF%BC%81%E7%9D%BE%E8%B4%B5%E7%9A%84%E7%B4%AB%E8%89%B2%EF%BC%81&img=https://i.imgur.com/QncNJJ1.png&bgcolor1=a371f7&bgcolor2=8957e5'></img><img align='middle' src='https://hb.shuia.tk/?text=♂&bgcolor1=b100ffd9&img=https://i.imgur.com/dGqcpPU.jpg'></img><img align='middle' src='https://hb.shuia.tk/?text=VSCode&bgcolor1=24aff2&bgcolor2=0075b8&img=https://i.imgur.com/XksHKIV.jpg'></img><img align='middle' src='https://hb.shuia.tk/?text=JavaScript&bgcolor1=f7df37&bgcolor2=f7df37&color=333&img=https://i.imgur.com/de9PXVn.jpg'></img>

我的另一个名字是**shuia**
<sub>[@shuia](https://github.com/androidhtml)是我用于第一个的账户， [@outlookthe](https://github.com/outlookthe)是我的测试账号而[@hllqk](https://github.com/hllqk)是我的正式账号
</sub>

<div align=left>
<img width='400px' src='https://github-readme-stats.vercel.app/api?username=hllqk'>
<img src='https://stats.justsong.cn/api/bilibili/?id=227561303'>
</div>
<div align=center>
<img src='https://cloud.shuia.tk/img/555.png' width=380px />
<img src='https://github-readme-stats.vercel.app/api/top-langs/?username=hllqk&layout=compact&hide_border=true&langs_count=10' width='410px'>
</div>  
<br>
<div align=center>
<img src='https://genshin-card.getloli.com/9/257461679.png'>
<hr>

[<img align='middle' src='https://hb.shuia.tk/?text=个人主页&img=https://cloud.shuia.tk/img/FDT9Yeg.jpeg'></img>](https://cdn.shuia.tk/)[<img align='middle' src='https://hb.shuia.tk/?text=我的博客'></img>](http://www.shui.tk/)[<img align='middle' src='https://hb.shuia.tk/?text=联系我啊&img=https://cloud.shuia.tk/img/1FwssQY.jpeg'></img>](mailto:hllqk@outlook.com)

</div>`

`
