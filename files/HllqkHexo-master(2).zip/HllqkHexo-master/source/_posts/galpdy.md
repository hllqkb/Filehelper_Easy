---
abbrlink: ''
categories:
- hexo
cover: https://i.hllqk.cn/file/67e2369f99f2e75bb7e61.jpg
date: '2022-08-10 20:41:59'
tags:
- game
title: 世界第一(自稱)的galgame引擎
updated: '2024-08-27T18:21:14.257+08:00'
---
[潘大爺遊戲 (shuia.ml)](https://fd.shuia.ml/main/https://test.librian.net/Librian%E6%9C%AC%E9%AB%94/%E5%89%8D%E7%AB%AF/adv.html)

挺有意思的

官网:

[Librian - 世界第一的galgame引擎](https://librian.net/)

![https://cloud.shuia.tk/Qexo/2022/8/bd64606a553b02b7021a2d37f84bcd8c.jpeg](https://cloud.shuia.tk/Qexo/2022/8/bd64606a553b02b7021a2d37f84bcd8c.jpeg)
