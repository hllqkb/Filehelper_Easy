---
abbrlink: ''
categories: []
cover: https://i.hllqk.cn/file/1ca9948fa5a6aa1f401ad.jpg
date: '2022-08-11 12:55:55'
tags: []
title: 色色的拼音首字母缩写翻译
updated: '2024-08-27T18:22:04.828+08:00'
---
# 色色的拼音首字母缩写翻译

真如名字一样，运行输入缩小如yn就会翻译出幼女

[借鉴了大佬~~萝莉控~~的项目](https://github.com/RimoChan/bnhhsh)

~~只是无聊玩玩罢了~~

Github地址:[https://github.com/hllqk/sese-translator](https://github.com/hllqk/sese-translator)

![https://i0.hdslb.com/bfs/new_dyn/141cf973aeb6f64896602246f50444ef3537115075840154.jpg](https://cloud.shuia.tk/Qexo/2022/8/4f8193dd210ee94f9d318ab0289e9664.jpeg)
