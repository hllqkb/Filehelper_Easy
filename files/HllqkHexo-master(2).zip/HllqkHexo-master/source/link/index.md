---
date: 2022-08-10 14:09:42
title: 友情鏈接
type: link
updated: 2022-08-10 15:42:17
---<div id="qexo-friends"></div>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/qexo-static@1.1.3/hexo/friends/friends.css"/>
<script src="https://cdn.jsdelivr.net/npm/qexo-static@1.1.3/hexo/friends/friends.js"></script>
<script>loadQexoFriends("qexo-friends", "https://qqexo.vercel.app")</script>
<h3>提示：友链提交的参数缺一不可，且链接为了安全性考虑必须为https，否则无法提交，望了解</h3>
<div id="friends-api"></div>
<script src="https://unpkg.com/qexo-friends/friends-api.js"></script>
<script>qexo_friend_api("friends-api","https://qqexo.vercel.app");</script>
