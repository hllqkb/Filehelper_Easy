---
date: '2024-08-27T18:26:01.451806+08:00'
title: 友情鏈接
type: type
updated: '2024-08-27T18:26:02.208+08:00'
---
<div id="qexo-friends"></div>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/qexo-static@1.1.3/hexo/friends/friends.css"/>
<script src="https://cdn.jsdelivr.net/npm/qexo-static@1.1.3/hexo/friends/friends.js"></script>
<script>loadQexoFriends("qexo-friends", "https://admin.iadx.eu.org")</script>
<h3>提示：友链提交的参数缺一不可，且链接为了安全性考虑必须为https，否则无法提交，望了解</h3>
<div id="friends-api"></div>
<script src="https://unpkg.com/qexo-friends/friends-api.js"></script>
<script>qexo_friend_api("friends-api","https://admin.iadx.eu.org");</script>
