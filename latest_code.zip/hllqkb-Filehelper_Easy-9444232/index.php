<?php
require 'config.php';
require_once 'index.html';
// echo "<script>window.location.href='404.html';</script>";
?>